import Header from '@/components/Header'
// import MyBreadcrumbs from '@/components/MyBreadcrumbs'
import MyMenu from '@/components/MyMenu'
import { Layout } from 'antd'
import type { IRoute } from 'umi'
import styles from './index.module.less'

export default (props: IRoute) => {
    return (
        <Layout className={styles.page}>
            <Header />
            <div className={styles.layout}>
                <MyMenu {...props} />
                <div className={styles.content}>
                    <div className={styles.children}>{props.children}</div>
                </div>
            </div>
        </Layout>
    )
}
