import { useEffect, useState } from 'react'
import { message } from 'antd'
import { inject,observer } from 'mobx-react'
import 'dayjs/locale/zh-cn'
// import { getThemeClass } from '@/utils/changeTheme'
import initFontSize from '@/utils/initFontSize'
import type { IRoute } from 'umi'
import 'antd/dist/antd.less'
import '@/styles/global.css'
import Hooks from './hook'
// import type { SiteData } from '@/types'

const GlobalLayout = observer((props: IRoute) => {
    const { userStore, siteStore } = props || {}
    const { addOnlineListen, removeOnlineListen, redirectLogin, autoGetUserData, initPageSize } =
        Hooks()
    const noLayout = [
        '/404',
        '/500',
    ]

    const [themed, setThemed] = useState<boolean>(true)


    const getLayout = () => {
        let pathname = props?.history?.location?.pathname || ''
        if (noLayout.includes(pathname)) {
            return props.children
        } else {
            // const pathArr = props?.history?.location?.pathname.split('/')
            // if (pathArr.length > 1) {
            //     if (userLayout.includes(pathArr[1])) {
            //         return <User {...props} />
            //     } else {
            //         return <Global {...props} />
            //     }
            // }
            return props.children
        }
    }

    // const updateTheme = (data: SiteData) => {
    //     // eslint-disable-next-line no-param-reassign
    //     data = data || {}
    //     let { configList } = data
    //     configList = configList || []
    //     let themeObj: any = {}
    //     configList.map((item: any) => {
    //         if (item.key.includes('theme_color')) {
    //             themeObj[item.key] = item.value
    //         }
    //     })

    //     const themeClassObj = getThemeClass()
    //     themeClassObj.doChangeTheme(themeObj, () => {
    //         setThemed(true)
    //     })
    // }

    /**页面初始化 数据获取 */
    useEffect(() => {
        setThemed(true)
        addOnlineListen()
        initFontSize()
        autoGetUserData(()=>{})
        autoGetUserData(()=>{})
        siteStore.getSiteConfigByDebounce()
        window.self_store = { userStore, siteStore }
        message.config({
            top: 100,
            duration: 2,
            maxCount: 3,
        })
        initPageSize()
        return removeOnlineListen
    }, [])

    /**数据监听 获取数据成功后 根据sid和token重定向 */
    useEffect(() => {
        if (siteStore?.siteData?.data?.sid) {
            console.log(siteStore?.siteData?.data?.sid, 'siteStore?.siteData?.data?.sid')
            redirectLogin(siteStore?.siteData?.data?.sid, siteStore)
        }
    }, [siteStore?.siteData?.data?.sid])

    /**数据监听 获取数据成功后 根据siteData更新主题色 */
    // useEffect(() => {
    //     if (siteStore?.siteData?.data) {
    //         updateTheme(siteStore?.siteData?.data)
    //     }
    //     console.log(111)
    // }, [siteStore?.siteData?.data])

    console.log(12121)

    return themed ? getLayout() : null
})

export default inject('userStore', 'siteStore')(GlobalLayout)
