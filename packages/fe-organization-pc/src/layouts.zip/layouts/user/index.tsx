import Footer from '@/components/Footer'
import Header from '@/components/Header'
import { Layout } from 'antd'
import type { IRoute } from 'umi'
import styles from './index.module.less'
import { useEffect, useState } from 'react'
import { findSiteData } from '@wotu/wotu-components'
import type { THEME_ENUM } from '../const'
import { THEME_MAP } from '../const'

export default (props: IRoute) => {
    const [bg, setBg] = useState('')
    const [center, setCenter] = useState(false)
    useEffect(() => {
        const { siteData } = props.siteStore || {}
        let loginTheme: THEME_ENUM = Number(findSiteData(siteData, 'login_theme')?.value || '1')
        let loginBackend = findSiteData(siteData, 'login_backend')?.value || ''
        let loginFormPosition = Number(findSiteData(siteData, 'login_form_position')?.value || '1')
        if (loginTheme !== 4) {
            setBg(THEME_MAP[loginTheme]?.bg)
            setCenter(THEME_MAP[loginTheme]?.center)
        } else {
            setBg(loginBackend)
            setCenter(loginFormPosition === 1)
        }
    }, [props.siteStore])

    return (
        <Layout className={styles.page} style={{ backgroundImage: `url(${bg})` }}>
            <Header noUser={true} noBg={true} />
            <div className={styles.content}>
                <div className={styles.user_content} style={center ? {} : { marginLeft: '762px' }}>
                    {props.children}
                </div>
            </div>
            <Footer noBg={true} />
        </Layout>
    )
}
