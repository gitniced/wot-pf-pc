import { useEffect } from 'react'
import { message } from 'antd'
import { inject, observer } from 'mobx-react'
import 'dayjs/locale/zh-cn'
import initFontSize from '@/utils/initFontSize'
import type { IRoute } from 'umi'
import 'antd/dist/antd.less'
import '@/styles/global.css'
import Hooks from './hook'

const GlobalLayout = observer((props: IRoute) => {
    const { siteStore } = props || {}
    const { addOnlineListen, removeOnlineListen, redirectLogin } = Hooks()

    /**页面初始化 数据获取 */
    useEffect(() => {
        addOnlineListen()
        initFontSize()
        siteStore.getSiteConfigByDebounce()
        message.config({
            top: 100,
            duration: 2,
            maxCount: 3,
        })
        return removeOnlineListen
    }, [])

    /**数据监听 获取数据成功后 根据sid和pathname重定向 */
    useEffect(() => {
        if (siteStore?.siteData?.data?.sid) {
            redirectLogin(siteStore?.siteData?.data?.sid, siteStore?.siteData)
        }
    }, [siteStore?.siteData?.data?.sid, props.location.pathname])

    return props.children
})

export default inject('userStore', 'siteStore')(GlobalLayout)
